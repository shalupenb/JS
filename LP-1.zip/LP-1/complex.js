document.addEventListener('DOMContentLoaded', () => {
  window.obj = {
    "Name": "User",
    "Surname":  "Smith"
  };
  updateCurrentFields();
  const addEventButton = document.getElementById("add-field-button");
  if(addEventButton) addEventButton.onclick = addFieldClick;
});

function updateCurrentFields(){
  const currentFields = document.getElementById("current-fields");
  if(!currentFields) throw "Element #current-field not found";
  currentFields.innerHTML = "";
  for(let key in window.obj){
    currentFields.innerHTML += `${key}:${window.obj[key]}<br/>` ;
  }
}

function addFieldClick(){
  const newFieldName = document.getElementById("add-field-name");
  if(!newFieldName) throw "Element #add-field-name not found";
  const newFieldValue = document.getElementById("add-field-value");
  if(!newFieldValue) throw "Element #add-field-value not found";
  
  const fieldName = newFieldName.value;
  const fieldValue = newFieldValue.value;
  
  if(Object.keys(window.obj).includes(fieldName)) {
    alert(`В об'єкті вже наявне поле '${fieldName}'`);
    return;
  }
  
  if(Object.values(window.obj).includes(fieldValue)) {
    alert(`В об'єкті вже наявне поле із значенням '${fieldValue}'`);
    return;
  }
  
  window.obj[fieldName] = fieldValue;
  updateCurrentFields();
}