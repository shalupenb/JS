function Admin() {
  return (
    <div className="Admin">
      <h1>Admin</h1>
    </div>
  );
}

export default Admin;